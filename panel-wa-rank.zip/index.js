
const { default: makeWASocket, useMultiFileAuthState } = require("@whiskeysockets/baileys")
const fs = require("fs")
const { randomPass } = require("./lib/password")
const { getRank, setRank, delRank } = require("./lib/rank")

async function start(){
  const { state, saveCreds } = await useMultiFileAuthState("session")
  const sock = makeWASocket({ auth: state })
  sock.ev.on("creds.update", saveCreds)

  sock.ev.on("messages.upsert", async ({ messages }) => {
    const m = messages[0]
    if(!m.message) return
    const from = m.key.remoteJid
    const sender = (m.key.participant || from).split("@")[0]
    const text = m.message.conversation || m.message.extendedTextMessage?.text || ""
    const args = text.split(" ")
    const cmd = args[0]
    const rank = getRank(sender)

    const date = new Date().toLocaleDateString("id-ID")

    if(cmd === ".menu"){
      await sock.sendMessage(from, { 
        text: "📋 MENU PANEL\nRank Kamu: " + rank + "\n\n.cuser\n.cadp\n.chost\n.ccom\n\nCredits: Rexxy" 
      })
    }

    if(cmd === ".cmenu" && rank === 4){
      await sock.sendMessage(from, {
        text: "👑 OWNER MENU\n.setrank nomor 1-4\n.delrank nomor"
      })
    }

    if(cmd === ".setrank" && rank === 4){
      setRank(args[1], Number(args[2]))
      sock.sendMessage(from, { text: "✅ Rank berhasil diset" })
    }

    if(cmd === ".delrank" && rank === 4){
      delRank(args[1])
      sock.sendMessage(from, { text: "✅ Rank dihapus" })
    }

    if(cmd.startsWith(".c")){
      let name = args[1]
      let num = args[2]
      let pass = randomPass(name)
      let link = cmd === ".cadp" ? "https://cx.galaxyhost.biz.id" : "https://p4.pablocloud.biz.id/"

      sock.sendMessage(num + "@s.whatsapp.net", {
        text: `✅ Succes Create\nUser: ${name}\nPass: ${pass}\nLink: ${link}\nDate: ${date}`
      })
    }
  })
}

start()
